#include <unknwn.h>
#include "minhook/include/MinHook.h"
#include "offsets.h"
#include "utils.h"
#include "memory.h"

using namespace std;
DWORD64 GameBase = (DWORD64)GetModuleHandleA("DarkSoulsII.exe");

namespace Pointers {
	// your pointers and flags

	bool CallDeath(bool flag)
	{
		if (flag)
		{
			auto LocalPlayer = mem_read(GameBase + OFFSET::DarkSoulsII::LocalPlayer, DWORD64);
			if (!LocalPlayer)
				return false;

			auto a1 = mem_read(LocalPlayer + 0xD0, DWORD64);
			if (!a1)
				return false;

			auto a2 = mem_read(a1 + 0xB8, DWORD64);
			if (!a2)
				return false;

			mem_write(a2 + 0x759, 1, int);
			return true;
		}

		return false;
	}

	bool CheckValid()
	{
		auto Target = mem_read(GameBase + OFFSET::DarkSoulsII::BasePlayer, DWORD64);
		if (!Target)
			return false;

		return true;
	}
}

namespace Scripts {
	// ur scripts from CE here, im too lazy to add an example
	// inline assembly x64 does not work, write differently
}

namespace OriginalHook {
	typedef bool(__fastcall* IsDown)(DWORD64);
	IsDown OrigClientInput{ };
}

bool ClientInput(DWORD64 a1)
{
	// add here what u want

	if (!Pointers::CheckValid())
		return OriginalHook::OrigClientInput(a1);

	NopAddress((LPVOID)((DWORD64)GameBase + OFFSET::DarkSoulsII::Stamina), 6); // infinity stamina

	return OriginalHook::OrigClientInput(a1);
}

void HookAddress(void* Function, void** Original, void* Detour) {
	if (MH_Initialize() != MH_OK && MH_Initialize() != MH_ERROR_ALREADY_INITIALIZED) {
		MessageBox(0, (L"hook initialization was invalid"), 0, 0);
		return;
	}
	MH_CreateHook(Function, Detour, Original);
	MH_EnableHook(Function);
}

void MinHook()
{
	HookAddress((void*)(GameBase + OFFSET::IDA::ClientInput), (void**)&OriginalHook::OrigClientInput, ClientInput);
}