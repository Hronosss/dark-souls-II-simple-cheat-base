﻿#include "pch.h"
#include "hooks.h"
#include <iostream>
#include "minhook/include/MinHook.h"

void Initialize()
{
    MinHook();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    if (ul_reason_for_call != DLL_PROCESS_ATTACH)
        return false;

    const auto handle = CreateThread(nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(Initialize), hModule, 0, nullptr);
    if (handle != NULL)
        CloseHandle(handle);

    return TRUE;
}
