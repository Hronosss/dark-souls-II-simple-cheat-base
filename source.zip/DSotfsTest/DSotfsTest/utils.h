#define NOP 0x90

void NopAddress(PVOID address, int bytes) {
	DWORD d, ds;
	VirtualProtect(address, bytes, PAGE_EXECUTE_READWRITE, &d);
	memset(address, NOP, bytes); VirtualProtect(address, bytes, d, &ds);
}

void RestoreAddress(LPVOID addr, const char* oldInstr, int size)
{
	memcpy(addr, (LPVOID)oldInstr, size);
}
