namespace OFFSET {
	namespace DarkSoulsII {
		constexpr auto LocalPlayer = 0x16148F0;
		constexpr auto BasePlayer = 0x1616CF8;
		constexpr auto Stamina = 0x33367E;
	}
	namespace IDA {
		constexpr auto ClientInput = 0x3337C0;
	}
}