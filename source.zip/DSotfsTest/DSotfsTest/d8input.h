#pragma once
#include <unknwn.h>

extern HHOOK SysHook;
LRESULT CALLBACK keyDownHook(int code, WPARAM wParam, LPARAM lParam);
